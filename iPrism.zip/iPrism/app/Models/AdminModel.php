<?php
namespace App\Models;
use \CodeIgniter\Model;

class AdminModel extends Model{
    
    public function insertData($table,$data){
        
        $builder = $this->db->table($table);
        $res = $builder->insert($data);
        if($this->db->affectedRows() >= 1){
            return true;
        }else{
            return false;
        }
        
    }
    
    public function fetchData($table,$where){
        
        $builder = $this->db->table($table);
        $builder->where($where);
        $query   = $builder->get();
        return $query->getResultArray();
    }
    
    
    public function updateData($table,$where,$updtqry){
        
        $builder = $this->db->table($table);
        $builder->where($where);
        $builder->update($updtqry);
        if($this->db->affectedRows() >= 1){
            return true;
        }else{
            return false;
        }
    }
    
    public function deletedata($table,$where){
        
        $builder = $this->db->table($table);
        $builder->where($where);
        $builder->delete();
        if($this->db->affectedRows() >= 1){
            return true;
        }else{
            return false;
        }
    }    
    
}


?>