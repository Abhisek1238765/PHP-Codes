<!doctype html>
<html class="fixed header-dark" data-style-switcher-options="{'headerColor': 'dark'}">
<head> 
<?= $this->include('partials/admin/css.php'); ?> </head>
  <body>
    <section class="body">
      <?= $this->include('partials/admin/navigation.php'); ?>
      <div class="inner-wrapper">
        <?= $this->include('partials/admin/sidebar.php'); ?>
        <section role="main" class="content-body">
          <header class="page-header">
            <h2>PROFILE</h2>
            <div class="right-wrapper text-end">
              <ol class="breadcrumbs">
                <li>
                  <a href="<?= base_url();?>/dashboard">
                    <i class="bx bx-home-alt"></i>
                  </a>
                </li>
              </ol>
              <a class="sidebar-right-toggle" data-open="sidebar-right">
                <i class="fas fa-chevron-left"></i>
              </a>
            </div>
          </header>
          
          <?php if(session()->getTempdata('success')){ ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong><?= session()->getTempdata('success'); ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
                <?php } ?>	
    		
    		<?php if(session()->getTempdata('error')){ ?> 
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong><?= session()->getTempdata('error'); ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php } ?>
            
            
          <?php foreach($userdata as $admindata){} ?>
          <!-- ----------- Page Details Can be written here -->
          <form action="<?= base_url(); ?>dashboard" method="post" enctype="multipart/form-data" onsubmit="return checkfrm();">
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Username</label>
                <input type="text" class="form-control" name="usrname" id="usrname" aria-describedby="emailHelp" value="<?= $admindata['admin_username']; ?>">
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input type="text" class="form-control" value="<?= $admindata['name']; ?>" name="namme" id="namme" aria-describedby="emailHelp">
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email</label>
                <input type="email" class="form-control" value="<?= $admindata['email']; ?>" name="emaill" id="emaill" aria-describedby="emailHelp">
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Contact Number</label>
                <input type="number" class="form-control" onkeypress="if(this.value.length == 10){ return false; }" value="<?= $admindata['contact_number']; ?>" name="contcatt" id="contcatt" aria-describedby="emailHelp">
              </div>
              <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Image</label>
                <input type="file" class="form-control" name="imagee" id="imagee" aria-describedby="emailHelp">
              </div>
                <input type="hidden" value="<?= $admindata['admin_id']; ?>" name="updttidd">
              <div class="mb-3">
                <button type="submit" class="btn btn-primary">Update</button>
          	  </div>
          </form>
        </section>
      </div>
      <?= $this->include('partials/admin/calendar.php'); ?> 
    </section>
     <?= $this->include('partials/admin/js.php'); ?>
     <?= include('public/admin/ajax/dashboard.php'); ?> 

    <script src="<?= base_url(); ?>/public/admin/js/examples/examples.dashboard.js"></script>
  </body>
  </html>