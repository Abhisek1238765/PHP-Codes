<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/style.css">
<!------ Include the above in your HEAD tag ---------->

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
<?php if(session()->getTempdata('error')){ ?> <div class="alert alert-danger"><?= session()->getTempdata('error'); ?></div> <?php } ?>
    <!-- Icon -->
    <div class="fadeIn first">
      <img src="<?= base_url();?>/public/admin/assets/images/login.jpg" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form method="post" action="<?= base_url();?>login" onsubmit="return validateLoginform();">
      <input type="text" name="username" id="username" class="fadeIn second" placeholder="Username">
      <input type="password" name="usrpassword" id="usrpassword" class="fadeIn third" placeholder="Password">
      <input type="submit" class="fadeIn fourth" value="Log In" style="cursor:pointer;">
    </form>

  </div>
</div>
<?= include('public/admin/ajax/login.php'); ?>