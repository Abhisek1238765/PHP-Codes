<!doctype html>
<html class="fixed header-dark" data-style-switcher-options="{'headerColor': 'dark'}">
<head> 
<?= $this->include('partials/admin/css.php'); ?>

 </head>
  <body>
    <section class="body">
      <?= $this->include('partials/admin/navigation.php'); ?>
      <?= $this->include('partials/admin/header.php'); ?>
      <div class="inner-wrapper">
        <?= $this->include('partials/admin/sidebar.php'); ?>
        <section role="main" class="content-body">
          <header class="page-header">
            <h2>DASHBOARD</h2>
            <div class="right-wrapper text-end">
              <ol class="breadcrumbs">
                <li>
                  <a href="<?= base_url();?>/dashboard">
                    <i class="bx bx-home-alt"></i>
                  </a>
                </li>
              </ol>
              <a class="sidebar-right-toggle" data-open="sidebar-right">
                <i class="fas fa-chevron-left"></i>
              </a>
            </div>
          </header>
          <!-- ----------- Page Details Can be written here -->
          
          <div class="row">
          
          <?php if(session()->getTempdata('success')){ ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong><?= session()->getTempdata('success'); ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
                <?php } ?>	
    		
    		<?php if(session()->getTempdata('error')){ ?> 
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
              <strong><?= session()->getTempdata('error'); ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php } ?>
          
          
          
			<div class="col">
				<section class="card">
					<header class="card-header">										
						<h2 class="card-title" style="width: 20%;position: absolute;">User Details</h2>
						<button class="btn btn-success btn-sm" style="float:right;" onclick="adduser();"> ADD USER </button>
					</header>
					<div class="card-body">
						<table class="table table-bordered table-striped mb-0" id="datatable-tabletools">
							<thead>
								<tr>
								    <th>Sl No</th>
									<th>Username</th>
									<th>Name</th>
									<th>Email</th>
									<th>Contact Number</th>
									<th>Image</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
							<?php 
							$i=0;
							foreach($userdata as $userdata):
							$i++;
							?>
								<tr>
								   <td><?= $i;?></td>
								   <td><?= $userdata["admin_username"];?></td>
								   <td><?= $userdata["name"];?></td>
								   <td><?= $userdata["email"];?></td>
								   <td><?= $userdata["contact_number"];?></td>
								   <td><img src="<?= base_url();?>/public/admin/assets/images/<?= $userdata["image"];?>" width=100px height=100px></td>
								   <td>
								        <button type="button" class="btn btn-sm btn-info" onclick="editshw('<?= $userdata["admin_id"]?>');"> Edit </button>
								        <button type="button" class="btn btn-sm btn-danger" onclick="cnfrmdelete('<?= $userdata["admin_id"]?>');"> Delete </button>
								   </td>
								</tr>
							<?php 
							   endforeach;
							?>
							</tbody>
						</table>
					</div>
				</section>
			</div>
		</div>
        </section>
      </div>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
      <?= $this->include('partials/admin/calendar.php'); ?> 
    </section>
     <?= $this->include('partials/admin/js.php'); ?> 
     <?= include('public/admin/ajax/dashboard.php'); ?>
    <script src="<?= base_url(); ?>/public/admin/js/examples/examples.dashboard.js"></script>
  </body>
  </html>
  
  