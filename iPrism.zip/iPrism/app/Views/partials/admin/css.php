<meta charset="UTF-8">
<meta name="keywords" content="HTML5 Admin Template" />
<meta name="description" content="Porto Admin - Responsive HTML5 Template">
<meta name="author" content="okler.net">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/vendor/bootstrap/css/bootstrap.css" />		
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/vendor/animate/animate.compat.css">		
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/vendor/font-awesome/css/all.min.css" />		
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/vendor/boxicons/css/boxicons.min.css" />		
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/vendor/magnific-popup/magnific-popup.css" />		
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.css" />
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/css/theme.css" />
<link rel="stylesheet" href="<?= base_url();?>/public/admin/assets/css/custom.css">
<script src="<?= base_url();?>/public/admin/assets/vendor/modernizr/modernizr.js"></script>
<script src="<?= base_url();?>/public/admin/assets/master/style-switcher/style.switcher.localstorage.js"></script>
<style>
.nav-active{
background-color: #171717;
}
</style>