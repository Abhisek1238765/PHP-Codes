<?php

namespace App\Controllers;
use \App\Models\AdminModel;

class Home extends BaseController
{
    public $loginModel;
    public function __construct(){
        helper("form");
        $this->loginModel = new AdminModel();
        $this->session = session();   
    }
    public function index()
    {
        if ((isset($_SESSION['logged_user_id']))) {            
            return redirect()->to(base_url('dashboard'));            
        }
        
        if($this->request->getMethod() == "post"){
            $userid = $this->request->getVar('username');
            $password = $this->request->getVar('usrpassword');
            $pass = md5(sha1(md5(sha1($password))));
            
            $where= array('admin_username' => $userid,'usertype'=>0);
            $admindata = $this->loginModel->fetchData("admin",$where);
            
            if(sizeof($admindata) == 0){
                $this->session->setTempdata('error','Invalid User Id', 3);
                return redirect()->to(current_url());
            }else{
                foreach($admindata as $admindata){}
                
                if($admindata['admin_password'] == $pass){
                    $profileImage=$admindata['image'];                    
                        
                    if($admindata['status'] == 0){
                            
                            if (!empty($_SERVER['HTTP_CLIENT_IP']))
                            {
                                $ip = $_SERVER['HTTP_CLIENT_IP'];
                            }
                            elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
                            {
                                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
                            }
                            else
                            {
                                $ip = $_SERVER['REMOTE_ADDR'];
                            }
                            
                            $dtm = date("Y-m-d h:i:s");
                            $tm = time();
                            
                            $data = ["user_ip_add"=>$ip,'user_type'=>0,'login_id'=>$admindata['admin_id'],'datetime_login'=>$dtm,'date_logout'=>$dtm,'timevalue'=>$tm];
                            
                            $loginData = $this->loginModel->insertData('login_data',$data);
                            $lid = $this->loginModel->db->insertID();
                            
                          
                            $this->session->set('logged_user_id',$admindata['admin_id']);
                            $this->session->set('logged_intype',"Admin");
                            $this->session->set('login_data_id',$lid);
                            $this->session->set('logged_img',$profileImage);                            
                            $this->session->set('usrName',$admindata['name']);
                            
                            
                            return redirect()->to(base_url().'dashboard');
                            
                            
                        }else{
                            $this->session->setTempdata('error','Your Account Has Been Locked ! Contact Support', 3);
                            return redirect()->to(current_url());
                        }                       
                    
                }else{
                    $this->session->setTempdata('error','Invalid Password', 3);
                    return redirect()->to(current_url());
                }
            }
        }
        
        return view('login');
    }
    
    public function dashboard()
    {
        if ((!isset($_SESSION['logged_user_id']))) {
            return redirect()->to(base_url('login'));
        }
        
        if($this->request->getMethod() == "post"){
            if($this->request->getVar('userid')){
                $userid = $this->request->getVar('userid');
                $rowid =$this->request->getVar('rowid');
                $where= array('admin_id' => $userid,'usertype'=>1);
                $admindata = $this->loginModel->fetchData("admin",$where);
                foreach($admindata as $admindata){}
                
                $response='
                    <form action="'.base_url().'dashboard" method="post" enctype="multipart/form-data" onsubmit="return checkfrm();">
                     <div class="modal-body">
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Username</label>
                        <input type="text" class="form-control" name="usrname" id="usrname" aria-describedby="emailHelp" value="'.$admindata['admin_username'].'">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Name</label>
                        <input type="text" class="form-control" value="'.$admindata['name'].'" name="namme" id="namme" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email</label>
                        <input type="email" class="form-control" value="'.$admindata['email'].'" name="emaill" id="emaill" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Contact Number</label>
                        <input type="number" class="form-control" onkeypress="if(this.value.length == 10){ return false; }" value="'.$admindata['contact_number'].'" name="contcatt" id="contcatt" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Image</label>
                        <input type="file" class="form-control" name="imagee" id="imagee" aria-describedby="emailHelp">
                      </div>
                        <input type="hidden" value="'.$userid.'" name="updttidd">
                    </div>
                    <div class="modal-footer fotr">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  </div>
                  </form>
                ';
                echo $response;
                exit;
            }
            
            
            if($this->request->getVar('useriddelete')){
                $userid = $this->request->getVar('useriddelete');
                $where= array('admin_id' => $userid,'usertype'=>1);
                $admindata = $this->loginModel->fetchData("admin",$where);
                foreach($admindata as $admindata){}
                
                $response='
                    <form>
                     <div class="modal-body">
                      <div class="mb-12">
                        <label for="exampleInputEmail1" class="form-label">Are you confirm you want to Delete User <strong>'.$admindata["admin_username"].'</strong></label>
                      </div>
                      </div>
                      <div class="modal-footer fotr">
                        <button type="button" class="btn btn-primary" onclick="deletee(\''.$userid.'\');">Delete</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                      </div>
                  </form>
                ';
                echo $response;
                exit;
            }
            
            if($this->request->getVar('dele')){
                $deleteidd = $this->request->getVar('dele');
               
                $where =array("admin_id"=>$deleteidd);
                if($this->loginModel->deletedata("admin",$where)){
                    $response="done";
                }else{
                    $response="Try Again Later";
                }
                echo $response;
                exit;
            }
            
            
            if($this->request->getVar('usrname')){
                $usrname = $this->request->getVar('usrname');
                $namme = $this->request->getVar('namme');
                $emaill = $this->request->getVar('emaill');
                $contcatt = $this->request->getVar('contcatt');
                $updttidd = $this->request->getVar('updttidd');
                
                $where= array('admin_id' => $updttidd);
                $admindata = $this->loginModel->fetchData("admin",$where);
                //print_r($admindata);
                foreach($admindata as $admindata1){}
                                
                if(!empty($this->request->getFile('imagee'))){
                    if($this->request->getFile('imagee')){
                        $imagee = $this->request->getFile('imagee');
                        $profileImage=$_FILES['imagee']['name'];
                        if($profileImage){
                            $filetype = pathinfo($profileImage, PATHINFO_EXTENSION);
                            $newprofilr = $imagee->getRandomName();
                            $imagee->move(FCPATH.'public/admin/assets/images/',$newprofilr);
                            $profileImage=$newprofilr;
                        }else{
                            $profileImage =$admindata1["image"];
                        }
                    }
                }
                
                
                $where =array("admin_id"=>$updttidd);
                $updtqry= array("admin_username"=>$usrname,"name"=>$namme, "email"=>$emaill,"contact_number"=>$contcatt, "image"=>$profileImage);
                $brandupdate = $this->loginModel->updateData("admin",$where,$updtqry);
                if($updttidd == 1){
                    
                    $this->session->set('logged_img',$profileImage);
                    $this->session->set('usrName',$namme);
                    
                    $this->session->setTempdata('success','Data Updated Successfully', 3);
                    return redirect()->to(base_url().'profile');
                    
                    
                }else{
                    $this->session->setTempdata('success','Data Updated Successfully', 3);
                    return redirect()->to(current_url());                    
                }
                
                exit;
            }
            
            
            if($this->request->getVar('adduser')){
                
                $response='
                    <form action="'.base_url().'user" method="post" enctype="multipart/form-data" onsubmit="return checkaddfrm();">
                     <div class="modal-body">
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Username</label>
                        <input type="text" class="form-control" name="usrname" id="usrname" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Name</label>
                        <input type="text" class="form-control" name="namme" id="namme" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Email</label>
                        <input type="email" class="form-control" name="emaill" id="emaill" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Contact Number</label>
                        <input type="number" class="form-control" onkeypress="if(this.value.length == 10){ return false; }" name="contcatt" id="contcatt" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Image</label>
                        <input type="file" class="form-control" name="imagee" id="imagee" aria-describedby="emailHelp">
                      </div>
                      <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Password</label>
                        <input type="password" class="form-control" name="pswd" id="pswd" aria-describedby="emailHelp">
                      </div>
                    </div>
                    <div class="modal-footer fotr">
                    <button type="submit" class="btn btn-primary">Add</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  </div>
                  </form>
                ';
                echo $response;
                exit;
            }
            
        }
        
        
        $data =[];
        
        $where= array('status' => 0,'usertype'=>1);
        $admindata = $this->loginModel->fetchData("admin",$where);
        $data["userdata"] = $admindata;
        return view('dashboard',$data);
    }
    
    public function logout(){
        $this->session->destroy();
        return redirect()->to(base_url('login'));
    }
    
    public function profile(){
        if ((!isset($_SESSION['logged_user_id']))) {
            return redirect()->to(base_url('login'));
        }
        $data=[];
        
        $where= array('admin_id' => $_SESSION["logged_user_id"],'usertype'=>0);
        $admindata = $this->loginModel->fetchData("admin",$where);
        $data['userdata'] = $admindata;
        
        return view('profile',$data);
    }
    
    public function user()
    {
        if ((!isset($_SESSION['logged_user_id']))) {
            return redirect()->to(base_url('login'));
        }
        
        $data=[];
        
        $usrname = $this->request->getVar('usrname');
        $namme = $this->request->getVar('namme');
        $emaill = $this->request->getVar('emaill');
        $contcatt = $this->request->getVar('contcatt');
        $pswd = $this->request->getVar('pswd');
        $pswd = md5(sha1(md5(sha1($pswd))));
        
        if(!empty($this->request->getFile('imagee'))){
            if($this->request->getFile('imagee')){
                $imagee = $this->request->getFile('imagee');
                $profileImage=$_FILES['imagee']['name'];
                if($profileImage){
                    $filetype = pathinfo($profileImage, PATHINFO_EXTENSION);
                    $newprofilr = $imagee->getRandomName();
                    $imagee->move(FCPATH.'public/admin/assets/images/',$newprofilr);
                    $profileImage=$newprofilr;
                }else{
                    $profileImage ="";
                }
            }
        }
        
        $data = ["admin_username"=>$usrname,"name"=>$namme, "email"=>$emaill,"contact_number"=>$contcatt, "image"=>$profileImage, "admin_password"=>$pswd, "usertype"=>1, "status"=>0, "datetime"=>date("Y-m-d h:i:s")];        
        $loginData = $this->loginModel->insertData('admin',$data);
        
        if($loginData){
            $this->session->setTempdata('success','User Added Successfully', 3);
            return redirect()->to(base_url().'dashboard');
        }
        
        
    }
}
