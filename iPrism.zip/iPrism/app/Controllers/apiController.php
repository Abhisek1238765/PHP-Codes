<?php

namespace App\Controllers;
use \App\Models\AdminModel;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;

class apiController extends BaseController
{
    public $loginModel;
    use ResponseTrait;


    public function __construct(){
        helper("form");
        $this->loginModel = new AdminModel();
        $this->session = session();        
    } 
  
  
  	public function userlogin(){

  	    if($this->request->getMethod() == "post"){
            if($this->request->getVar('usrid')){
                $userid = $this->request->getVar('usrid');
                $password = $this->request->getVar('password');
                $pass = md5(sha1(md5(sha1($password))));
               
                
                $where= array('admin_username' => $userid);
                $admindata = $this->loginModel->fetchData("admin",$where);
                
                
                if(sizeof($admindata) == 0){
                    $response = [
                        'status'   => 200,
                        'error'    => true,
                        'messages' => [
                            'responsecode'=>"00",
                            'status' => 'Invalid User'
                        ]
                    ];                
                }else{
                    foreach($admindata as $admindata){}
                    
                    if($admindata['admin_password'] == $pass){
                        if($admindata['status'] == 0){
                            $response = [
                                'status'   => 200,
                                'error'    => true,
                                'messages' => [
                                    'responsecode'=>"00",
                                    'status' => $admindata
                                ]
                            ];
                            
                        }else{
                            $response = [
                                'status'   => 200,
                                'error'    => true,
                                'messages' => [
                                    'responsecode'=>"00",
                                    'status' => 'Account Locked Connect Admin'
                                ]
                            ];
                        }
                    
                    }else{
                        $response = [
                            'status'   => 200,
                            'error'    => true,
                            'messages' => [
                                'responsecode'=>"00",
                                'status' => 'Invalid Password'
                            ]
                        ];
                    }
                }
            }
            return $this->respond($response);
  	    }
  	  } 	
  	        
    

  	     public function getUserlist(){
  	         
  	             
  	             $where= array('status' => 0, 'usertype'=>1);
  	             $admindata = $this->loginModel->fetchData("admin",$where);
  	             
  	                 $response = [
  	                     'status'   => 200,
  	                     'error'    => true,
  	                     'messages' => [
  	                         'responsecode'=>"00",
  	                         'status' => $admindata
  	                     ]
  	                 ];
  	             
  	             return $this->respond($response);
  	         
  	     }
  	     
  	     
  	     public function updateprofilepic(){
  	         
  	         if($this->request->getMethod() == "post"){
  	             if($this->request->getVar('usrid')){
  	                 $userid = $this->request->getVar('usrid');
  	                 $password = $this->request->getVar('password');
  	                 $pass = md5(sha1(md5(sha1($password))));
  	                 
  	                 
  	                 $where= array('admin_username' => $userid);
  	                 $admindata = $this->loginModel->fetchData("admin",$where);
  	                 
  	                 
  	                 if(sizeof($admindata) == 0){
  	                     $response = [
  	                         'status'   => 200,
  	                         'error'    => true,
  	                         'messages' => [
  	                             'responsecode'=>"00",
  	                             'status' => 'Invalid User'
  	                         ]
  	                     ];
  	                 }else{
  	                     foreach($admindata as $admindata){}
  	                     
  	                     if($admindata['admin_password'] == $pass){
  	                         if($admindata['status'] == 0){
  	                             
  	                             if($this->request->getFile('profilepic')){
  	                                 $prfimg = $this->request->getFile('profilepic');
  	                                 $profileImage=$_FILES['profilepic']['name'];
  	                                 if($profileImage){
  	                                     $filetype = pathinfo($profileImage, PATHINFO_EXTENSION);
  	                                     $newprofilr = $prfimg->getRandomName();
  	                                     $prfimg->move(FCPATH.'public/admin/assets/images/',$newprofilr);
  	                                     $profileImage=$newprofilr;
  	                                 }else{
  	                                     $profileImage =$admindata['image'];
  	                                 }
  	                             }else{
  	                                 $profileImage =$admindata['image'];
  	                             }
  	                             
  	                             $where =array("admin_id"=>$admindata["admin_id"]);
  	                             $updtqry= array("image"=>$profileImage);
  	                             $brandupdate = $this->loginModel->updateData("admin",$where,$updtqry);
  	                             if($brandupdate){
  	                                 $dt = "Profile Updated Successfully";
  	                             }else{
  	                                 $dt = "Sorry Unable To Update";
  	                             }
  	                             
  	                             
  	                             $response = [
  	                                 'status'   => 200,
  	                                 'error'    => true,
  	                                 'messages' => [
  	                                     'responsecode'=>"00",
  	                                     'status' => $admindata,
  	                                     "sts"=>$dt
  	                                 ]
  	                             ];
  	                             
  	                         }else{
  	                             $response = [
  	                                 'status'   => 200,
  	                                 'error'    => true,
  	                                 'messages' => [
  	                                     'responsecode'=>"00",
  	                                     'status' => 'Account Locked Connect Admin'
  	                                 ]
  	                             ];
  	                         }
  	                         
  	                     }else{
  	                         $response = [
  	                             'status'   => 200,
  	                             'error'    => true,
  	                             'messages' => [
  	                                 'responsecode'=>"00",
  	                                 'status' => 'Invalid Password'
  	                             ]
  	                         ];
  	                     }
  	                 }
  	             }
  	             return $this->respond($response);
  	         }
  	     }


}


?>