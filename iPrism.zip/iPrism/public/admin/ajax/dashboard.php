<script> 

function editshw(val){
    var userid = val;
    
    $.ajax({
        type:'post',
        url:'<?= base_url(); ?>dashboard',
        data:{userid:userid,rowid:1},
        success: function(data){
            $(".modbody").html(data);
            $("#staticBackdrop").modal("show");           
        }
    });
}

function cnfrmdelete(val){
    var useriddelete = val;
    
    $.ajax({
        type:'post',
        url:'<?= base_url(); ?>dashboard',
        data:{useriddelete:useriddelete},
        success: function(data){
            $(".modbody").html(data);
            $("#staticBackdrop").modal("show");           
        }
    });
}

function deletee(val){
   var dele = val;
   $.ajax({
        type:'post',
        url:'<?= base_url(); ?>dashboard',
        data:{dele:dele},
        success: function(data){
            location.reload();           
        }
    });

}

function adduser(){
    
    $.ajax({
        type:'post',
        url:'<?= base_url(); ?>dashboard',
        data:{adduser:true},
        success: function(data){
            $(".modbody").html(data);
            $("#staticBackdrop").modal("show");           
        }
    });
}


function checkfrm(){

var usernamm = document.getElementById("usrname").value;
var namme = document.getElementById("namme").value;
var emaille = document.getElementById("emaill").value;
var cntctt = document.getElementById("contcatt").value;

if(usernamm =="" || namme =="" || emaille =="" || cntctt ==""){   
    if(usernamm ==""){
        document.getElementById("usrname").style.border="1px solid red";
    }else{
        document.getElementById("usrname").style.border="";
        $(".usr").html("");
    }
    if(namme ==""){
        document.getElementById("namme").style.border="1px solid red";
    }else{
        document.getElementById("namme").style.border="";
    }
    if(emaille ==""){
        document.getElementById("emaill").style.border="1px solid red";
    }else{
        document.getElementById("emaill").style.border="";
    }
    if(cntctt ==""){
        document.getElementById("contcatt").style.border="1px solid red";
    }else{
        document.getElementById("contcatt").style.border="";
    }
    return false;
 }else if(cntctt.length < 10){
       document.getElementById("contcatt").style.border="1px solid red";
       return false;
 }else{    
    return true; 	  
 }
    
  
}


function checkaddfrm(){

var usernamm = document.getElementById("usrname").value;
var namme = document.getElementById("namme").value;
var emaille = document.getElementById("emaill").value;
var cntctt = document.getElementById("contcatt").value;
var imagee = document.getElementById("imagee").value;
var pswd = document.getElementById("pswd").value;

if(usernamm =="" || namme =="" || emaille =="" || cntctt =="" || imagee =="" || pswd ==""){   
    if(usernamm ==""){
        document.getElementById("usrname").style.border="1px solid red";
    }else{
        document.getElementById("usrname").style.border="";
        $(".usr").html("");
    }
    if(namme ==""){
        document.getElementById("namme").style.border="1px solid red";
    }else{
        document.getElementById("namme").style.border="";
    }
    if(emaille ==""){
        document.getElementById("emaill").style.border="1px solid red";
    }else{
        document.getElementById("emaill").style.border="";
    }
    if(cntctt ==""){
        document.getElementById("contcatt").style.border="1px solid red";
    }else{
        document.getElementById("contcatt").style.border="";
    }
    
    if(imagee ==""){
        document.getElementById("imagee").style.border="1px solid red";
    }else{
        document.getElementById("imagee").style.border="";
        $(".usr").html("");
    }
    if(pswd ==""){
        document.getElementById("pswd").style.border="1px solid red";
    }else{
        document.getElementById("pswd").style.border="";
    }
    return false;
 }else if(cntctt.length < 10){
       document.getElementById("contcatt").style.border="1px solid red";
       return false;
 }else{    
    return true; 	  
 }
    
  
}

</script>