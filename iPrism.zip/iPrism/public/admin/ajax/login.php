<script> 


function validateLoginform(){
    var username = document.getElementById('username').value;
    var usrpassword = document.getElementById('usrpassword').value;
    
    if(username =="" || usrpassword ==""){
        if(username ==""){
            document.getElementById('username').style.border="1px solid red";
            $(".usr").html("Username Is Required");
        }else{
            document.getElementById('username').style.border="";
            $(".usr").html("");
        }
        if(usrpassword ==""){
            document.getElementById('usrpassword').style.border="1px solid red";
            $(".pass").html("Password Is Required");
        }else{
            document.getElementById('usrpassword').style.border="";
            $(".pass").html("");
        }
        
        return false;
    }
}



</script>